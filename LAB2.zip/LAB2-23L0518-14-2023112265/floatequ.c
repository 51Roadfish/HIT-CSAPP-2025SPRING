#include <stdio.h>

void main()
{
        double a = 646616.10;
        double b = 234732.45;

        double c = a + b;

        printf("%.2lf\n", a);
        printf("%.2lf\n", b);
        printf("%.2lf\n", c);

        if (c == 881348.55)
                printf("OK!\n");
        else
                printf("Error!\n");
	return 0;
}
