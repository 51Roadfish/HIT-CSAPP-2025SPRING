#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>


// 计算 UTF-8 字符串的字符个数
int utf8len(const char* str)
{
    int n = 0; // 字符个数
    while (*str != '\0')
    {
        // 判断当前字符的字节数
        if ((*str & 0x80) == 0) // 1 字节字符
        {
            str += 1; // 移动到下一个字符
        }
        else if ((*str & 0xE0) == 0xC0) // 2 字节字符
        {
            str += 2;
        }
        else if ((*str & 0xF0) == 0xE0) // 3 字节字符
        {
            str += 3;
        }
        else if ((*str & 0xF8) == 0xF0) // 4 字节字符
        {
            str += 4;
        }
        else
        {
            // 非法 UTF-8 字符
            printf("错误：非法 UTF-8 字符！\n");
            return -1;
        }
        n++; // 字符个数加 1
    }
    return n;
}

int main()
{
    char str[100];

    printf("请输入一个 UTF-8 字符串: ");
    fgets(str, sizeof(str), stdin); // 使用 fgets 读取输入

    // 去掉 fgets 读取的换行符
    for (int i = 0; str[i] != '\0'; i++)
    {
        if (str[i] == '\n')
        {
            str[i] = '\0';
            break;
        }
    }


    int len = utf8len(str); // 计算 UTF-8 字符个数

    if (len != -1)
    {
        printf("UTF-8 字符串的字符个数为: %d\n", len);
    }

    return 0;
}
