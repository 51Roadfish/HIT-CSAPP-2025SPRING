#include <stdio.h>
#include <stdint.h>

void print_hex(const char* name, const void* ptr, size_t size) {
    printf("%s (hex): ", name);
    const unsigned char* bytes = (const unsigned char*)ptr;
    for (size_t i = 0; i < size; i++) {
        printf("%02X ", bytes[i]);
    }
    printf("\n");
}

int main() {
    float a = 646616.10f;
    float b = 234732.45f;
    float c = a + b;

    float target = 881348.55f;

    // 打印变量 c 的机器级表示
    print_hex("c", &c, sizeof(float));

    // 打印常量 881348.55 的机器级表示
    print_hex("881348.55", &target, sizeof(float));

    return 0;
}
