#include <stdio.h>

// 全局整型常量
const int x = -2023112265;

void print_info() {
    // 局部浮点常量
    const long double y = 341802200508292422.0L;
    
    // 静态局部字符串常量（学号-姓名）
    static const char* z = "2023112265-余璐";

    // 分行打印三个变量
    printf("x = %d\n", x);       // 打印整型
    printf("y = %.0Lf\n", y);     // 打印浮点型（不显示小数）
    printf("z = %s\n", z);       // 打印字符串
}

int main() {
    print_info();
    return 0;
}
