#include <stdio.h>

// 全局字符数组
char cstr[100] = "2023112265-余璐";

// 全局字符指针
char *pstr = "2023112265-余璐";

int main() {
    // 打印 cstr 和 pstr 的内容
    printf("cstr: %s\n", cstr);
    printf("pstr: %s\n", pstr);

    // 打印 cstr 和 pstr 的地址
    printf("Address of cstr: %p\n", (void*)cstr);
    printf("Address of pstr: %p\n", (void*)pstr);

    return 0;
}
