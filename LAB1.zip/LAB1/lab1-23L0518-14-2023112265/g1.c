#include <stdio.h>
#include <stdlib.h>
long f(int n)
{

    if(n==0||n==1)
    {

        return 1;
    }
    else{
        return f(n-1)+f(n-2);
    }

}
int main()
{
    int n;
    printf("input:\n");
    scanf("%d",&n);
    float g=f(n)/f(n-1);
    printf("float g=%.8f\n",g);
    double d=f(n)/f(n-1);
    printf("double g=%.8lf",d);

    return 0;
}
