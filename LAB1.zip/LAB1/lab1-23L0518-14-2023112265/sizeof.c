#include <stdio.h>
int main() {
    printf("int %ld\n", sizeof(int));
    printf("float %ld\n", sizeof(float));
    printf("double %ld\n", sizeof(double));
    printf("short %ld\n", sizeof(short));
    printf("char %ld\n", sizeof(char));
    printf("long %ld\n", sizeof(long));
    printf("long long  %ld\n", sizeof(long long));
    printf("long double %ld\n", sizeof(long double));
    printf("int* %ld\n", sizeof(int *));
}
