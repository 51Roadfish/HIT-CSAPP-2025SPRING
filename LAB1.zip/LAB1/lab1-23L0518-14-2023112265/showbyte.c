#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *fp = NULL;
    fp = fopen("hellolinux.c", "r");
    if (fp == NULL) {
        perror("Failed to open file");
        return 1;
    }

    // 获取文件大小
    fseek(fp, 0, SEEK_END);
    long size = ftell(fp);
    rewind(fp);

    // 分配内存
    char *buf = (char *)malloc(size * sizeof(char));
    if (buf == NULL) {
        perror("Failed to allocate memory");
        fclose(fp);
        return 1;
    }

    // 读取文件内容
    size_t read_size = fread(buf, 1, size, fp);
    if (read_size != size) {
        perror("Failed to read file");
        free(buf);
        fclose(fp);
        return 1;
    }
    fclose(fp);

    // 输出内容
    for (int i = 0; i < size; i += 16) {
        // 输出偏移量（十六进制），使用 %06x 格式
        printf("%06x ", i);

        // 输出字符形式
        if (i == 0 ||i==16||i==32|| i == 48||i==64) {  // 第一行和第四行
            printf("  ");  // 添加一个字符位
	} else {
            printf(" ");  // 其他行添加两个字符位
        }

        for (int j = 0; j < 16; ++j) {
            if (i + j < size) {
                unsigned char ch = (unsigned char)buf[i + j];
                if (j == 0) {
                    // 每行的第一个字符不添加额外空格
                    if (ch == '\n') {
                        printf("\\n ");
                    } else if (ch == '\t') {
                        printf("\\t ");
                    } else if (ch == ' ') {
                        printf("   ");
                    } else if (ch < 32 || ch >= 127) {
                        if (ch >= 128) {
                            printf("%03o ", ch);  // 大于 128 的字符以八进制输出
                        } else {
                            printf("\\%02x ", ch);  // 其他非可打印字符以十六进制输出
                        }
                    } else {
                        printf("%c ", ch);  // 可打印字符
                    }
                } else {
                    // 其他字符正常输出
                    if (ch == '\n') {
                        printf(" \\n ");
                    } else if (ch == '\t') {
                        printf(" \\t ");
                    } else if (ch == ' ') {
                        printf("    ");
                    } else if (ch < 32 || ch >= 127) {
                        if (ch >= 128) {
                            printf("%03o ", ch);  // 大于 128 的字符以八进制输出
                        } else {
                            printf("\\%02x ", ch);  // 其他非可打印字符以十六进制输出
                        }
                    } else {
                        printf("  %c ", ch);  // 可打印字符
                    }
                }
            } else {
                printf("    ");  // 不足 16 个字符时补齐空白
            }
        }

        printf("\n");

        // 输出十六进制值
        printf("       ");  // 对齐偏移量
        for (int j = 0; j < 16; ++j) {
            if (i + j < size) {
                printf(" %02x ", (unsigned char)buf[i + j]);  // 十六进制值，占 4 个字符宽度
            } else {
                printf("    ");  // 不足 16 个字符时补齐空白
            }
        }

        printf("\n");
    }

    // 释放内存
    free(buf);
    return 0;
}

