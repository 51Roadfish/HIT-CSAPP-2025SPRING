#include <stdio.h>
#include <stdlib.h>
int fib[102]={0};
int f(int n){
    fib[0]=1;
    fib[1]=1;
    int i=2;
    if(n==1||n==2)
    {

        return 1;
    }
    for(i=2;i<=n;i++)
    {

        fib[i]=fib[i-1]+fib[i-2];
    }
    return fib[n];
}
int main()
{

    int n;
    printf("input n:\n");
    scanf("%d",&n);
    float d =(float)(f(n))/(float)(f(n+1));
    printf("float g=%.8f\n",d);
    double g =(double)(f(n))/(double)(f(n+1));
    printf("double g=%.8lf\n",g);
return 0;
}
