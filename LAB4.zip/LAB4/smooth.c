#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define ROWS 5120
#define COLS 8192
#define CACHE_BLOCK 64  // 根据L1缓存调整分块大小

long long img[ROWS][COLS];   // 原图像及平滑后的图像
long long val[ROWS][COLS];   // 比较平滑结果是否正确的图像
long long backup[ROWS][COLS]; // 备份原始数据

void cache() {
    const int last_row = ROWS - 2;
    const int last_col = COLS - 2;

    for (int ii = 1; ii <= last_row; ii += CACHE_BLOCK) {
        int i_end = ii + CACHE_BLOCK;
        if (i_end > last_row) i_end = last_row;

        // 计算块内所有行
        for (int i = ii; i <= i_end; i++) {
            long long* prev = &backup[i - 1][0];
            long long* curr = &backup[i][0];
            long long* next = &backup[i + 1][0];
            long long* dst = &img[i][0];

            for (int j = 1; j <= last_col; j++) {
                dst[j] = (prev[j] + next[j] + curr[j - 1] + curr[j + 1]) / 4;
            }
        }
    }
}

void cpu() {
#pragma omp parallel for
    for (int i = 1; i < ROWS - 1; i++) {
        long long* prev = &backup[i - 1][0];
        long long* next = &backup[i + 1][0];
        long long* curr = &backup[i][0];
        long long* dst = &img[i][0];

        // 展开8次+SIMD友好
        int j;
        for (j = 1; j <= COLS - 9; j += 8) {
            dst[j] = (prev[j] + next[j] + curr[j - 1] + curr[j + 1]) >> 2;
            dst[j + 1] = (prev[j + 1] + next[j + 1] + curr[j] + curr[j + 2]) >> 2;
            dst[j + 2] = (prev[j + 2] + next[j + 2] + curr[j + 1] + curr[j + 3]) >> 2;
            dst[j + 3] = (prev[j + 3] + next[j + 3] + curr[j + 2] + curr[j + 4]) >> 2;
            dst[j + 4] = (prev[j + 4] + next[j + 4] + curr[j + 3] + curr[j + 5]) >> 2;
            dst[j + 5] = (prev[j + 5] + next[j + 5] + curr[j + 4] + curr[j + 6]) >> 2;
            dst[j + 6] = (prev[j + 6] + next[j + 6] + curr[j + 5] + curr[j + 7]) >> 2;
            dst[j + 7] = (prev[j + 7] + next[j + 7] + curr[j + 6] + curr[j + 8]) >> 2;
        }

        // 处理剩余元素
        for (; j < COLS - 1; j++) {
            dst[j] = (prev[j] + next[j] + curr[j - 1] + curr[j + 1]) >> 2;
        }
    }
}

void smooth() {
    for (int i = 1; i < ROWS - 1; i++) {
        for (int j = 1; j < COLS - 1; j++) {
            img[i][j] = (backup[i - 1][j] + backup[i + 1][j] + backup[i][j - 1] + backup[i][j + 1]) / 4;
        }
    }
}
void smooth1()
{
    int i, j;
    long long tmp[WIDTH];   // 行缓存数组，用于保存中间计算结果
    long long* p_img = &img[0][0]; // 图像数据的指针表示
    long long t, t_0;       // 辅助变量

    for (j = 1; j < WIDTH - 1; j++)
        t = WIDTH + j; // 计算下一行的偏移量
    tmp[j] = (p_img[j] +
        p_img[t + WIDTH] +
        p_img[t - 1] +
        p_img[t + 1]) >> 2;
    t = WIDTH;
    // 逐行处理图像
    for (i = 1; i < HEIGHT - 1; i++) {
        for (j = 1; j < WIDTH - 1; j++) {
            t_0 = t + j; // 计算当前像素的绝对偏移量
            // 指针，计算相邻像素
            long long* p = p_img + t_0;
            color = (*(p - WIDTH) +  // 上像素
                *(p + WIDTH) +  // 下像素
                *(p - 1) +      // 左像素
                *(p + 1)) >> 2; // 右像素

            // 将上一行的计算结果写入当前行
            *(p - WIDTH) = tmp[j];
            tmp[j] = color;
        }
        t += WIDTH;
    }
    // 最后一行
    for (j = 1; j < WIDTH - 1; j++)
        img[i - 1][j] = tmp[j];
}
void main()
{
    int i, j;
    long long color;

    srand(time(NULL));
    printf("图像各行各列初始化为随机值！\n");

    for (i = 0; i < ROWS; i++)
        for (j = 0; j < COLS; j++)
        {
            img[i][j] = rand();
            backup[i][j] = img[i][j]; // 备份原始数据
        }

    for (i = 1; i < ROWS - 1; i++)
        for (j = 1; j < COLS - 1; j++)
            val[i][j] = (img[i - 1][j] + img[i + 1][j] + img[i][j - 1] + img[i][j + 1]) / 4;

    int count = 150;
    clock_t start, end;
    double time_smooth;

    start = clock();
    for (int m = 0; m < count; m++)
    {
        memcpy(img, backup, sizeof(img)); // 恢复原始数据
        smooth();
    }
    end = clock();
    time_smooth = (double)(end - start) / CLOCKS_PER_SEC;
    printf("优化前执行时间: %.3f 秒\n", time_smooth);

    start = clock();
    for (int m = 0; m < count; m++)
    {
        memcpy(img, backup, sizeof(img)); // 恢复原始数据
        cpu();
    }
    end = clock();
    time_smooth = (double)(end - start) / CLOCKS_PER_SEC;
    printf("CPU优化后执行时间: %.3f 秒\n", time_smooth);

    start = clock();
    for (int m = 0; m < count; m++)
    {
        memcpy(img, backup, sizeof(img)); // 恢复原始数据
        cache();
    }
    end = clock();
    time_smooth = (double)(end - start) / CLOCKS_PER_SEC;
    printf("cache优化后执行时间: %.3f 秒\n", time_smooth);

    start = clock();
    for (int m = 0; m < count; m++)
    {
        memcpy(img, backup, sizeof(img)); // 恢复原始数据
        smooth1();
    }
    end = clock();
    time_smooth = (double)(end - start) / CLOCKS_PER_SEC;
    printf("一般优化后执行时间: %.3f 秒\n", time_smooth);

    for (i = 1; i < ROWS - 1; i++)
        for (j = 1; j < COLS - 1; j++)
            if (img[i][j] != val[i][j])
            {
                printf("%d %d %lld %lld\n", i, j, img[i][j], val[i][j]);
                printf("平滑算法执行结果错误，异常退出 !\n");
                exit(1);
            }
    printf("程序正常执行结束，平滑结果正确!\n");
}
