#include <stdio.h>
#include <unistd.h> 
#include <stdlib.h>

int main(int argc,char *argv[]){
	int i;

	if(argc!=5){
		printf("用法: Hello 学号 姓名 手机号 秒数！\n");
		exit(1);
	}
	for(i=0;i<10;i++){
		printf("Hello %s %s %s\n",argv[1],argv[2],argv[3]);
		sleep(atoi(argv[4]));
	}
	getchar();
	return 0;
}
